import { z } from "zod";
export const DifficultySchema = z.enum(["easy", "medium", "hard"]);
export type Difficulty = z.infer<typeof DifficultySchema>;

export interface QuestionProvenance { name: string; url?: string; license: string; attribution?: string }
export interface NormalizedQuestion {
  id: string; text: string; type: "single_choice"; options: string[]; correctIndex: number;
  explanation: string; topic: string; subtopic?: string; difficulty: Difficulty; marks: number;
  source: QuestionProvenance; importedAt: string;
}
export interface SourceRequest { topic: string; difficulty: Difficulty; count: number }
export interface SourceResult { source: string; ok: boolean; questions: NormalizedQuestion[]; notes: string[] }
/** Add new providers by implementing this; the generator never changes. */
export interface QuestionSource { readonly id: string; readonly name: string; fetchQuestions(req: SourceRequest): Promise<SourceResult> }

export const GeneratorSettingsSchema = z.object({
  topic: z.string().trim().min(2).max(80).default("Python Programming"),
  difficulty: DifficultySchema.default("medium"),
  count: z.number().int().min(1).max(50).default(20),
  timeLimitMinutes: z.number().int().min(1).max(180).default(15),
  sources: z.array(z.enum(["opentdb", "curated"])).min(1).default(["opentdb", "curated"]),
});
export type GeneratorSettings = z.infer<typeof GeneratorSettingsSchema>;
