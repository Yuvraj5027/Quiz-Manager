import type { NormalizedQuestion } from "../types.js";
/** Returns a list of problems; empty means the question is structurally valid. */
export function validateQuestion(q: NormalizedQuestion): string[] {
  const e: string[] = [];
  if (!q.id) e.push("missing id");
  if (!q.text || q.text.trim().length < 10) e.push("text too short");
  if (q.options.length < 2 || q.options.length > 6) e.push("needs 2-6 options");
  if (new Set(q.options.map((o) => o.trim().toLowerCase())).size !== q.options.length) e.push("duplicate options");
  if (q.options.some((o) => !o.trim())) e.push("empty option");
  if (!Number.isInteger(q.correctIndex) || q.correctIndex < 0 || q.correctIndex >= q.options.length) e.push("invalid answer key");
  if (!q.source?.name || !q.source?.license) e.push("missing provenance/license");
  if (q.marks <= 0) e.push("marks must be positive");
  return e;
}
