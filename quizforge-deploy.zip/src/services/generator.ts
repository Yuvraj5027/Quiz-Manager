import { GeneratorSettingsSchema, type GeneratorSettings, type NormalizedQuestion, type QuestionSource } from "../types.js";
import { validateQuestion } from "./validation.js";
import { matchesRequest, dedupeKey } from "./matching.js";

export interface Coverage { requested: number; available: number; perSource: Record<string, { ok: boolean; fetched: number; usable: number }>; notes: string[]; sufficient: boolean }
export class SmartQuizGenerator {
  constructor(private sources: QuestionSource[]) {}
  async collect(input: unknown): Promise<{ settings: GeneratorSettings; pool: NormalizedQuestion[]; coverage: Coverage }> {
    const settings = GeneratorSettingsSchema.parse(input ?? {});
    const chosen = this.sources.filter((s) => settings.sources.includes(s.id as "opentdb" | "curated"));
    const results = await Promise.all(chosen.map((s) => s.fetchQuestions(settings)));
    const seen = new Set<string>(); const pool: NormalizedQuestion[] = [];
    const coverage: Coverage = { requested: settings.count, available: 0, perSource: {}, notes: [], sufficient: false };
    for (const r of results) {
      let usable = 0;
      for (const q of r.questions) {
        if (validateQuestion(q).length || !matchesRequest(q, settings) || seen.has(dedupeKey(q))) continue;
        seen.add(dedupeKey(q)); pool.push(q); usable++;
      }
      coverage.perSource[r.source] = { ok: r.ok, fetched: r.questions.length, usable };
      coverage.notes.push(...r.notes);
    }
    coverage.available = pool.length; coverage.sufficient = pool.length >= settings.count;
    if (!results.some((r) => r.ok)) coverage.notes.push("All selected sources failed. Please retry.");
    else if (!coverage.sufficient) coverage.notes.push(`Only ${pool.length} suitable question(s) available; ${settings.count} requested.`);
    return { settings, pool, coverage };
  }
  /** Never pads with off-topic questions: returns fewer than requested unless the pool is large enough. */
  async generate(input: unknown) {
    const { settings, pool, coverage } = await this.collect(input);
    const questions = [...pool].sort(() => Math.random() - 0.5).slice(0, settings.count);
    return { settings, questions, coverage, actualCount: questions.length };
  }
}
