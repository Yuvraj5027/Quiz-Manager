import type { NormalizedQuestion, SourceRequest } from "../types.js";
const STOP = new Set(["programming", "language", "basics", "the", "and", "of", "in"]);
/** A question matches when its topic field or text mentions every significant topic keyword. Unrelated trivia is rejected, never used as filler. */
export function matchesTopic(q: NormalizedQuestion, topic: string): boolean {
  const keys = topic.toLowerCase().split(/\W+/).filter((k) => k && !STOP.has(k));
  if (!keys.length) return false;
  const hay = `${q.topic} ${q.subtopic ?? ""} ${q.text}`.toLowerCase();
  return keys.every((k) => hay.includes(k));
}
export const matchesRequest = (q: NormalizedQuestion, r: SourceRequest) =>
  q.difficulty === r.difficulty && matchesTopic(q, r.topic);
export const dedupeKey = (q: NormalizedQuestion) => q.text.toLowerCase().replace(/\W+/g, " ").trim();
