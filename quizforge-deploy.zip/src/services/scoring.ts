export interface ScoredQuestion { id: string; correctIndex: number; marks: number }
/** Server-side only. `answers` maps questionId -> selected option index. Never accept scores from clients. */
export function scoreAttempt(questions: ScoredQuestion[], answers: Record<string, number | undefined>, passPercent: number) {
  const max = questions.reduce((s, q) => s + q.marks, 0);
  const earned = questions.reduce((s, q) => s + (answers[q.id] === q.correctIndex ? q.marks : 0), 0);
  const percentage = max === 0 ? 0 : Math.round((earned / max) * 10000) / 100;
  return { earned, max, percentage, passed: percentage >= passPercent };
}
