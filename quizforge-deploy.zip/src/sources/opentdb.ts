import { createHash } from "node:crypto";
import type { Difficulty, NormalizedQuestion, QuestionSource, SourceRequest, SourceResult } from "../types.js";
const CODES: Record<number, string> = { 1: "no results for these filters", 2: "invalid parameter", 3: "token not found", 4: "token exhausted", 5: "rate limited (1 request / 5s per IP)" };
interface Raw { category: string; type: string; difficulty: string; question: string; correct_answer: string; incorrect_answers: string[] }
const dec = (s: string) => decodeURIComponent(s); // we request encode=url3986, so no HTML-entity guessing
export class OpenTDBAdapter implements QuestionSource {
  readonly id = "opentdb"; readonly name = "Open Trivia Database";
  constructor(private fetchImpl: typeof fetch = fetch, private timeoutMs = 8000) {}
  async fetchQuestions(r: SourceRequest): Promise<SourceResult> {
    const fail = (n: string): SourceResult => ({ source: this.id, ok: false, questions: [], notes: [n] });
    // OpenTDB has no Python category; request the Computers category (18) and let the matcher filter by content.
    const url = `https://opentdb.com/api.php?amount=50&category=18&difficulty=${r.difficulty}&type=multiple&encode=url3986`;
    try {
      const res = await this.fetchImpl(url, { signal: AbortSignal.timeout(this.timeoutMs) });
      if (!res.ok) return fail(`Open Trivia DB HTTP ${res.status}`);
      const body = (await res.json()) as { response_code?: number; results?: Raw[] };
      if (typeof body.response_code !== "number" || !Array.isArray(body.results)) return fail("Open Trivia DB returned a malformed response");
      if (body.response_code !== 0) return fail(`Open Trivia DB: ${CODES[body.response_code] ?? "error " + body.response_code}`);
      const questions = body.results.map((x) => this.normalize(x)).filter((q): q is NormalizedQuestion => q !== null);
      return { source: this.id, ok: true, questions, notes: ["Open Trivia DB has no Python category; only content-matched questions are used."] };
    } catch (e) { return fail(`Open Trivia DB unavailable: ${(e as Error).message}`); }
  }
  private normalize(x: Raw): NormalizedQuestion | null {
    try {
      const text = dec(x.question), correct = dec(x.correct_answer), wrong = x.incorrect_answers.map(dec);
      const options = [...wrong, correct].sort(); // deterministic order; correctIndex derived below
      return {
        id: "opentdb-" + createHash("sha1").update(text).digest("hex").slice(0, 12), text, type: "single_choice", options,
        correctIndex: options.indexOf(correct), explanation: "", topic: dec(x.category), difficulty: x.difficulty as Difficulty, marks: 1,
        importedAt: new Date().toISOString(),
        source: { name: "Open Trivia Database", url: "https://opentdb.com", license: "CC BY-SA 4.0", attribution: "Questions from Open Trivia Database (opentdb.com), CC BY-SA 4.0" },
      };
    } catch { return null; }
  }
}
