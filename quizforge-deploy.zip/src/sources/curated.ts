import { readFile } from "node:fs/promises";
import type { NormalizedQuestion, QuestionSource, SourceRequest, SourceResult } from "../types.js";
export class CuratedQuestionBankAdapter implements QuestionSource {
  readonly id = "curated"; readonly name = "Curated Question Banks";
  constructor(private files: string[] = ["data/question-banks/python-medium.json"]) {}
  async load(): Promise<NormalizedQuestion[]> {
    const out: NormalizedQuestion[] = [];
    for (const f of this.files) {
      const { meta, questions } = JSON.parse(await readFile(f, "utf8"));
      for (const q of questions) out.push({
        id: q.id, text: q.text, type: "single_choice", options: q.options, correctIndex: q.answer,
        explanation: q.explanation, topic: meta.topic, subtopic: q.subtopic, difficulty: meta.difficulty,
        marks: q.marks ?? meta.marks, importedAt: meta.createdAt,
        source: { name: meta.sourceName, license: meta.license, url: meta.sourceUrl },
      });
    }
    return out;
  }
  async fetchQuestions(_r: SourceRequest): Promise<SourceResult> {
    try { return { source: this.id, ok: true, questions: await this.load(), notes: [] }; }
    catch (e) { return { source: this.id, ok: false, questions: [], notes: [`Curated bank unreadable: ${(e as Error).message}`] }; }
  }
}
