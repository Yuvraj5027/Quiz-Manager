import type { VercelRequest, VercelResponse } from "@vercel/node";
import { z } from "zod";
import { unseal } from "./_lib.js";
import { scoreAttempt } from "../src/services/scoring.js";

const Body = z.object({ token: z.string().max(20000), answers: z.record(z.number().int().min(0).max(9)) });
export default function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });
  const p = Body.safeParse(req.body);
  if (!p.success) return res.status(400).json({ error: "Invalid request" });
  let t: { deadline: number; q: { id: string; c: number; m: number; e: string }[] };
  try { t = unseal(p.data.token); } catch { return res.status(400).json({ error: "Invalid or tampered attempt token" }); }
  if (Date.now() > t.deadline + 15_000) return res.status(403).json({ error: "Time limit exceeded" }); // 15s network grace for auto-submit
  const result = scoreAttempt(t.q.map((x) => ({ id: x.id, correctIndex: x.c, marks: x.m })), p.data.answers, 40);
  res.status(200).json({ ...result, review: t.q.map((x) => ({ id: x.id, correctIndex: x.c, explanation: x.e, yourAnswer: p.data.answers[x.id] ?? null })) });
}
