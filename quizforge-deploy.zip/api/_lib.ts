import { createCipheriv, createDecipheriv, createHash, randomBytes } from "node:crypto";
import { SmartQuizGenerator } from "../src/services/generator.js";
import { OpenTDBAdapter } from "../src/sources/opentdb.js";
import { CuratedQuestionBankAdapter } from "../src/sources/curated.js";

export const generator = new SmartQuizGenerator([new OpenTDBAdapter(), new CuratedQuestionBankAdapter()]);
// Stateless attempt token: AES-256-GCM sealed answer key + deadline. Clients cannot read or alter it.
const key = createHash("sha256").update(process.env.QUIZ_SECRET ?? "dev-only-secret-change-me").digest();
export function seal(o: unknown): string {
  const iv = randomBytes(12), c = createCipheriv("aes-256-gcm", key, iv);
  const enc = Buffer.concat([c.update(JSON.stringify(o)), c.final()]);
  return Buffer.concat([iv, c.getAuthTag(), enc]).toString("base64url");
}
export function unseal<T>(t: string): T {
  const b = Buffer.from(t, "base64url"), d = createDecipheriv("aes-256-gcm", key, b.subarray(0, 12));
  d.setAuthTag(b.subarray(12, 28));
  return JSON.parse(Buffer.concat([d.update(b.subarray(28)), d.final()]).toString());
}
