import type { VercelRequest, VercelResponse } from "@vercel/node";
import { ZodError } from "zod";
import { generator, seal } from "./_lib.js";

export default async function handler(req: VercelRequest, res: VercelResponse) {
  if (req.method !== "POST") return res.status(405).json({ error: "Use POST" });
  try {
    const r = await generator.generate(req.body ?? {});
    if (r.actualCount === 0)
      return res.status(200).json({ quiz: null, coverage: r.coverage, message: "No suitable questions found for these settings." });
    const qs = r.questions.map((q) => { // shuffle options, remap the key
      const idx = q.options.map((_, i) => i).sort(() => Math.random() - 0.5);
      return { ...q, options: idx.map((i) => q.options[i]), correctIndex: idx.indexOf(q.correctIndex) };
    });
    const deadline = Date.now() + r.settings.timeLimitMinutes * 60_000;
    const token = seal({ deadline, q: qs.map((q) => ({ id: q.id, c: q.correctIndex, m: q.marks, e: q.explanation })) });
    res.status(200).json({
      quiz: { token, deadline, settings: r.settings, requested: r.settings.count, actualCount: r.actualCount,
        questions: qs.map((q) => ({ id: q.id, text: q.text, options: q.options, marks: q.marks, source: q.source })) },
      coverage: r.coverage,
    });
  } catch (e) {
    if (e instanceof ZodError) return res.status(400).json({ error: "Invalid settings", details: e.issues });
    res.status(500).json({ error: "Could not generate quiz. Please retry." });
  }
}
