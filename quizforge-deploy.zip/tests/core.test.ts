import { describe, it, expect } from "vitest";
import { CuratedQuestionBankAdapter } from "../src/sources/curated.js";
import { OpenTDBAdapter } from "../src/sources/opentdb.js";
import { SmartQuizGenerator } from "../src/services/generator.js";
import { validateQuestion } from "../src/services/validation.js";
import { scoreAttempt } from "../src/services/scoring.js";

describe("curated bank", () => {
  it("has unique ids, valid answer keys and metadata", async () => {
    const qs = await new CuratedQuestionBankAdapter().load();
    expect(new Set(qs.map((q) => q.id)).size).toBe(qs.length);
    for (const q of qs) expect(validateQuestion(q), q.id).toEqual([]);
  });
});
describe("generator", () => {
  const down = new OpenTDBAdapter((async () => { throw new Error("offline"); }) as unknown as typeof fetch);
  it("falls back to curated and reports shortfall honestly", async () => {
    const r = await new SmartQuizGenerator([down, new CuratedQuestionBankAdapter()]).generate({});
    expect(r.actualCount).toBeLessThan(20);
    expect(r.coverage.sufficient).toBe(false);
    expect(r.coverage.perSource.opentdb.ok).toBe(false);
  });
  it("rejects off-topic trivia", async () => {
    const trivia = new OpenTDBAdapter((async () => ({ ok: true, json: async () => ({ response_code: 0, results: [{ category: "Geography", type: "multiple", difficulty: "medium", question: "Capital%20of%20France%3F", correct_answer: "Paris", incorrect_answers: ["Rome", "Madrid", "Berlin"] }] }) })) as unknown as typeof fetch);
    const r = await new SmartQuizGenerator([trivia]).generate({ sources: ["opentdb"] });
    expect(r.actualCount).toBe(0);
  });
});
describe("scoring", () => {
  it("scores on the server", () => {
    const r = scoreAttempt([{ id: "a", correctIndex: 1, marks: 1 }, { id: "b", correctIndex: 0, marks: 1 }], { a: 1, b: 2 }, 40);
    expect(r).toEqual({ earned: 1, max: 2, percentage: 50, passed: true });
  });
});
