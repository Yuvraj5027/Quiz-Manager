# QuizForge
Smart quiz generator: pulls questions from Open Trivia DB (CC BY-SA 4.0) and an original curated Python bank, validates, topic-matches, de-duplicates, reports honest source coverage, and scores on the server (sealed AES-GCM attempt token with server-enforced deadline).

## Run locally
    npm install && npm test && npx vercel dev

## Deploy (Vercel)
1. Push to GitHub. 2. vercel.com → Add New → Project → import the repo (no build settings needed).
3. Settings → Environment Variables → `QUIZ_SECRET` = long random string. 4. Deploy.

## Roadmap
Auth + roles, PostgreSQL/Prisma persistence, attempt history, teacher/admin dashboards, more question banks.
